﻿using ComicApiWeb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ComicApiWeb.Controllers
{
    public class ComicApiController : ApiController
    {
        // GET: api/ComicApi
        public IEnumerable<Comic> Get()
        {
            return new Comic[] { };
        }

        // GET: api/ComicApi/5
        public Comic Get(int comic_id)
        {
            string[] paras = new string[1] { "comic_id" };
            object[] values = new object[1] { comic_id };
            string query = "SELECT name, summary, trans, author, genre_id, comic_id FROM Comic WHERE comic_id = @comic_id";
            DataSet data = Connection.Connection.FillDataSet(query, paras, values);
            Comic com = new Comic();
            if (data.Tables[0].Rows.Count > 0)
            {
                com.comic_id = Convert.ToInt32(data.Tables[0].Rows[0]["comic_id"].ToString());
                com.name = data.Tables[0].Rows[0]["name"].ToString();
                com.summary = data.Tables[0].Rows[0]["summary"].ToString();
                com.trans = data.Tables[0].Rows[0]["trans"].ToString();
                com.author = data.Tables[0].Rows[0]["author"].ToString();
                com.genre_id = Convert.ToInt32(data.Tables[0].Rows[0]["genre_id"].ToString());
            }
            paras = new string[1] { "comic_id" };
            values = new object[1] { comic_id };
            query = "SELECT chapter_id, name, update_time FROM Chapter WHERE comic_id = @comic_id";
            DataSet dataChapter = Connection.Connection.FillDataSet(query, paras, values);
            if(dataChapter.Tables[0].Rows.Count > 0)
            {
                List<Chapter> chapters = new List<Chapter>();
                for(int i = 0; i < dataChapter.Tables[0].Rows.Count; i++)
                {
                    Chapter chapter = new Chapter();
                    chapter.chapter_id = Convert.ToInt32(dataChapter.Tables[0].Rows[i]["chapter_id"].ToString());
                    chapter.name = dataChapter.Tables[0].Rows[i]["name"].ToString();
                    chapter.update_time = Convert.ToDateTime(dataChapter.Tables[0].Rows[i]["update_time"].ToString());
                    chapters.Add(chapter);
                }
                com.chapters = chapters.ToArray();
            }
            return com;
        }

        // POST: api/ComicApi
        public bool Post([FromBody]Comic comic, string KEY)
        {
            if (Userr.checkLogin(KEY) != 1)
                return false;

            if (string.IsNullOrWhiteSpace(comic.name) || comic.genre_id == 0 || string.IsNullOrWhiteSpace(comic.image))
                return false;

            //  Create folder
            string folderID = Drive.createFolder(comic.name, Drive.folderRootID);
            if (string.IsNullOrEmpty(folderID))
                return false;

            //save image to server
            Image image = Base64String.Base64ToImage(comic.image);
            string folderPath = @"/Images/";
            var baseUrl = AppDomain.CurrentDomain.BaseDirectory + folderPath;
            string fileName = "jpg";
            string newFileName = Guid.NewGuid().ToString() + "." + fileName;
            string newPath = baseUrl + newFileName;

            var i2 = new Bitmap(image);
            i2.Save(newPath);

            //upload image to drive
            List<String> imageName = new List<string> { baseUrl + newFileName };
            if (!Drive.uploadFile(folderID, imageName.ToArray()))
            {
                Drive.deleteFolder(folderID);
                return false;
            }
            string imageID = Drive.fileIDs.ToArray()[0];

            //save to db
            string[] paras = new string[7] { "name", "summary", "author", "trans", "genre_id", "image", "folderID" };
            object[] values = new object[7] { comic.name, comic.summary, comic.author, comic.trans, comic.genre_id, imageID, folderID };
            string query = "INSERT INTO Comic(name, summary, author, trans, genre_id, image, folderID) VALUES(@name, @summary, @author, @trans, @genre_id, @image, @folderID)";
            int result = Connection.Connection.ExcuteNonQuery(query, paras, values);
            if (result <= 0) {
                //failure
                Drive.deleteFolder(folderID);
                return false;
            }
            return true;
        }

        // PUT: api/ComicApi/5
        public int Put(int comic_id, [FromBody]Comic comic)
        {
            string[] paras = new string[7] { "comic_id", "name", "summary", "author", "trans", "genre_id", "image" };
            object[] values = new object[7] { comic_id, comic.name, comic.summary, comic.author, comic.trans, comic.genre_id, comic.image };
            return Connection.Connection.RequestStatus("sp_Comic_UPDATE_byComicID", CommandType.StoredProcedure, paras, values);
        }

        // DELETE: api/ComicApi/5
        public int Delete(int comic_id)
        {
            string[] paras = new string[1] { "comic_id" };
            object[] values = new object[1] { comic_id };
            return Connection.Connection.RequestStatus("sp_Comic_DELETE_byComicID", CommandType.StoredProcedure, paras, values);
        }
    }
}
